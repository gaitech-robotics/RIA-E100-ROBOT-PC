/**
 * @file wheel_driver.h
 * @brief This is a header file for wheel driver 
 * @author Rui-Jun Yan, hityrj@outlook.com
 * @version 1.1.2
 * @date 2018-10-14
 */

#ifndef _WHEEL_H
#define _WHEEL_H

#include<stdio.h>  
#include<stdlib.h> 
#include<string> 
#include<unistd.h>  
#include<sys/types.h>  
#include<sys/stat.h>  
#include<sys/signal.h>  
#include<fcntl.h>  
#include<termios.h>  
#include<errno.h> 
#include <thread>
#include <mutex>

#define uchar unsigned char
#define uint unsigned int

namespace GaiTech{
class WheelZLAC
{
	public:
		WheelZLAC(float r = 0.1, float trans_acc = 0.5);
		~WheelZLAC();

		int voltage_read;
		int battery_read;
		int voltage;
		int battery;
		int current;

		float odom;
		float LinAcc; // acceleration value
		float LastCmd; // last command velocity
		float LastOdom; // Last odometry data
		float FeedbackOdom;
		std::string TempPort;

		bool init(const char* port, int baud);
		bool SetWheelSpeed(float speed = 0.0, float dt = 0.033, uint acc = 20, uint dec = 20);
		void stop(void);
	
	private:
		static const int SpeedArray[10];
		static const int BaudArray[10];
		const float WheelRadius;

		uchar SpeedMode[4];
		uchar SpeedAcc[4];
		uchar SpeedEnable[4];
		uchar SpeedCmd[4];
		uchar FeedBackCmd[3];
		uchar FeedBackStr[32];
		uchar StopCmd[4];
		uchar TempByteVec[2];

		uint AccVal;
		uint DecVal;

		std::mutex  mutex_read;
		std::mutex mutex_write;

		double LastData;

		int fd;
		uchar *buff;
		uchar *RecvBuff;

		uchar atohex(uchar);
		uchar hextoa(uchar);
		int hextodec(uchar S[2]);
		void dectohex(int d, uchar S[2]);
		void GetCmd(uchar S[4]);
		int SpeedToRpm(float speed);
		float RpmToSpeed(int rpm);
		int OpenDev(const char *dev);
		void CloseDev(void);
		void SetBaud(int);
		int SetParity(int, int, int);
		int WriteData(uchar*, int);
		int ReadData(uchar*, int, bool output = true);
};

}//namespace
#endif